package me.txmc.core;

/**
 * @author 254n_m
 * @since 2023/12/26 12:44 AM
 * This file was created as a part of 8b8tCore
 */
public interface Reloadable {
    void reloadConfig();
}
