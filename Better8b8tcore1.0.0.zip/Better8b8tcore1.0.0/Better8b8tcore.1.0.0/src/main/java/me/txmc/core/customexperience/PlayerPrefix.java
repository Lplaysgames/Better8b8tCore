package me.txmc.core.customexperience;

import me.txmc.core.Main;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Handles player prefixes based on ranks defined in config.yml and permissions.
 */
public class PlayerPrefix implements Listener {

    private final JavaPlugin plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final LinkedHashMap<String, Rank> ranks = new LinkedHashMap<>();

    public PlayerPrefix(JavaPlugin plugin) {
        this.plugin = plugin;
        loadRanks();
    }

    /**
     * Call this when a player joins
     */
    public void handlePlayerJoin(Player player) {
        // Optional bypass for certain names
        if (player.getName().startsWith(".")) {
            PermissionAttachment attachment = player.addAttachment(plugin);
            attachment.setPermission("nocheatplus.shortcut.bypass", true);
        }

        // Apply rank prefix from config + permissions
        applyPrefix(player);
    }

    /**
     * Load ranks from config.yml
     */
    public void loadRanks() {
        ConfigurationSection ranksSection = plugin.getConfig().getConfigurationSection("Ranks");
        if (ranksSection == null) return;

        ranks.clear();
        for (String key : ranksSection.getKeys(false)) {
            ConfigurationSection rankConfig = ranksSection.getConfigurationSection(key);
            if (rankConfig == null) continue;

            String prefix = rankConfig.getString("prefix", "&7");
            String permission = rankConfig.getString("permission", "better8b8tcore.rank." + key.toLowerCase());

            ranks.put(key, new Rank(key, prefix, permission));
        }
    }

    /**
     * Assign the highest priority rank prefix a player has.
     */
    public void applyPrefix(Player player) {
        Rank playerRank = null;

        // Iterate ranks in config order
        for (Rank rank : ranks.values()) {
            if (player.hasPermission(rank.getPermission())) {
                playerRank = rank;
                break; // take the first matching rank
            }
        }

        if (playerRank == null) {
            // Default rank fallback
            playerRank = ranks.getOrDefault("default", new Rank("default", "&7", "better8b8tcore.rank.default"));
        }

        setPlayerPrefix(player, playerRank.getPrefix());
    }

    /**
     * Set the player's display name and tablist prefix
     */
    private void setPlayerPrefix(Player player, String prefix) {
        String display = String.format("%s%s", prefix, player.getName());
        Component component = miniMessage.deserialize(display);
        player.displayName(component);
        player.playerListName(component);
    }

    /**
     * Simple rank data holder
     */
    private static class Rank {
        private final String name;
        private final String prefix;
        private final String permission;

        public Rank(String name, String prefix, String permission) {
            this.name = name;
            this.prefix = prefix;
            this.permission = permission;
        }

        public String getName() { return name; }
        public String getPrefix() { return prefix; }
        public String getPermission() { return permission; }
    }
}
