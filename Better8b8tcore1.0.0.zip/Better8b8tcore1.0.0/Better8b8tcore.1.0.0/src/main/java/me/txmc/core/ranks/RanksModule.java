package me.txmc.core.ranks;

import me.txmc.core.Main;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

/**
 * Handles server ranks and their prefixes.
 * Prefixes are assigned based on LuckPerms permissions.
 *
 * Example: For a rank "mod", create a permission in LP:
 * better8b8tcore.rank.mod
 */
public class RanksModule {

    private final Map<String, String> ranks = new HashMap<>();

    /**
     * Initializes the ranks module.
     * @param plugin The main plugin instance
     */
    public void enable(Main plugin) {
        loadRanks(plugin);
    }

    /**
     * Reloads ranks from config dynamically.
     */
    public void reloadConfig() {
        Main plugin = Main.getInstance();
        ranks.clear();
        loadRanks(plugin);
    }

    /**
     * Loads ranks and prefixes from config.yml
     * Expects section "Ranks":
     * Ranks:
     *   default:
     *     prefix: "&7"
     *   mod:
     *     prefix: "&2[Mod]"
     */
    private void loadRanks(Main plugin) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("Ranks");
        if (section == null) return;

        for (String rankName : section.getKeys(false)) {
            String prefix = section.getString(rankName + ".prefix", "");
            ranks.put(rankName.toLowerCase(), prefix);
        }
    }

    /**
     * Returns the prefix for the given player based on their LuckPerms group.
     * @param player The player
     * @return The prefix string
     */
    public String getPrefix(Player player) {
        // Check player's LuckPerms-based permissions
        // Each rank expects a permission like: better8b8tcore.rank.<rankname>
        return ranks.entrySet().stream()
                .filter(entry -> player.hasPermission("better8b8tcore.rank." + entry.getKey()))
                .map(Map.Entry::getValue)
                .findFirst()
                .orElse(ranks.getOrDefault("default", "&7"));
    }
}
